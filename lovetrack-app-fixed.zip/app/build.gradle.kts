plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.lovetrack.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lovetrack.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 14
        versionName = "0.11.1-fix-theme-duplicate"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.10"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

    // Navigation antar layar
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // ViewModel + state management (StateFlow), tanpa Hilt dulu sesuai kesepakatan
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")

    // Deteksi app pindah foreground/background (buat fitur Presence/Online-Last seen)
    implementation("androidx.lifecycle:lifecycle-process:2.7.0")

    // Manual location (one-shot, bukan background tracking)
    implementation("com.google.android.gms:play-services-location:21.2.0")

    // Map — MapLibre Native (open-source, tile dari MapTiler; percobaan pertama,
    // exit plan ke WebView+Leaflet kalau kejebak)
    implementation("org.maplibre.gl:android-sdk:11.5.2")

    // Firebase — pakai BoM biar versi antar library Firebase selalu kompatibel
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")

    // FCM "Thinking of You" — kirim/terima push notification lewat Cloudflare Worker
    implementation("com.google.firebase:firebase-messaging")
}
