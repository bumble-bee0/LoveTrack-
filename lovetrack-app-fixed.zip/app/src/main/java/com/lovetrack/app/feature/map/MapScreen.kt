package com.lovetrack.app.feature.map

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.lovetrack.app.location.LocationData
import com.lovetrack.app.location.LocationRepository
import com.lovetrack.app.util.awaitResult
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point

private const val SOURCE_ID = "lovetrack-locations-source"
private const val LAYER_ID = "lovetrack-locations-layer"

// Warna brand LoveTrack — dipakai lagi di sini biar marker konsisten sama tema
private const val COLOR_ME = "#5B5CE2"      // Indigo
private const val COLOR_PARTNER = "#F0568C" // Pink

@Composable
fun MapScreen() {
    val mapView = rememberMapViewWithLifecycle()
    val uid = FirebaseAuth.getInstance().currentUser?.uid

    var partnerUid by remember { mutableStateOf<String?>(null) }
    var myLocation by remember { mutableStateOf<LocationData?>(null) }
    var partnerLocation by remember { mutableStateOf<LocationData?>(null) }
    var statusText by remember { mutableStateOf("Memuat peta...") }
    var maplibreMapRef by remember { mutableStateOf<MapLibreMap?>(null) }

    // Cari siapa pasangannya (sama seperti logic di Home)
    LaunchedEffect(uid) {
        if (uid != null) {
            try {
                val userSnap = FirebaseFirestore.getInstance()
                    .collection("users").document(uid).get().awaitResult()
                val coupleId = userSnap.getString("coupleId")
                if (coupleId != null) {
                    val coupleSnap = FirebaseFirestore.getInstance()
                        .collection("couples").document(coupleId).get().awaitResult()
                    val user1 = coupleSnap.getString("user1")
                    val user2 = coupleSnap.getString("user2")
                    partnerUid = if (user1 == uid) user2 else user1
                }
            } catch (_: Exception) {
                statusText = "Gagal memuat data pasangan"
            }
        }
    }

    // Dengarkan lokasi diri sendiri
    DisposableEffect(uid) {
        val listener = uid?.let {
            LocationRepository().listenLocation(it) { loc -> myLocation = loc }
        }
        onDispose { listener?.remove() }
    }

    // Dengarkan lokasi pasangan
    DisposableEffect(partnerUid) {
        val listener = partnerUid?.let {
            LocationRepository().listenLocation(it) { loc -> partnerLocation = loc }
        }
        onDispose { listener?.remove() }
    }

    // Setiap kali salah satu lokasi berubah, gambar ulang marker di peta
    LaunchedEffect(myLocation, partnerLocation, maplibreMapRef) {
        val map = maplibreMapRef ?: return@LaunchedEffect
        map.getStyle { style ->
            updateMarkers(style, myLocation, partnerLocation)
            val firstPoint = myLocation ?: partnerLocation
            if (firstPoint != null) {
                map.cameraPosition = CameraPosition.Builder()
                    .target(LatLng(firstPoint.lat, firstPoint.lng))
                    .zoom(12.0)
                    .build()
                statusText = ""
            } else {
                statusText = "Belum ada lokasi yang dibagikan"
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(factory = { mapView }) { view ->
            view.getMapAsync { maplibreMap ->
                maplibreMapRef = maplibreMap
                maplibreMap.setStyle(Style.Builder().fromUri(MapConfig.STYLE_URL)) {
                    // Style berhasil dimuat, marker akan digambar lewat LaunchedEffect di atas
                }
            }
        }

        if (statusText.isNotEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                if (statusText == "Memuat peta...") {
                    CircularProgressIndicator()
                } else {
                    Text(statusText, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

/** Gambar ulang titik lokasi (diri sendiri warna indigo, pasangan warna pink) di peta. */
private fun updateMarkers(style: Style, mine: LocationData?, partner: LocationData?) {
    val features = mutableListOf<Feature>()

    mine?.let {
        val feature = Feature.fromGeometry(Point.fromLngLat(it.lng, it.lat))
        feature.addStringProperty("color", COLOR_ME)
        features.add(feature)
    }
    partner?.let {
        val feature = Feature.fromGeometry(Point.fromLngLat(it.lng, it.lat))
        feature.addStringProperty("color", COLOR_PARTNER)
        features.add(feature)
    }

    val existingSource = style.getSourceAs<GeoJsonSource>(SOURCE_ID)
    if (existingSource != null) {
        existingSource.setGeoJson(FeatureCollection.fromFeatures(features))
    } else {
        style.addSource(GeoJsonSource(SOURCE_ID, FeatureCollection.fromFeatures(features)))
        style.addLayer(
            CircleLayer(LAYER_ID, SOURCE_ID).withProperties(
                PropertyFactory.circleRadius(10f),
                PropertyFactory.circleColor(org.maplibre.android.style.expressions.Expression.get("color")),
                PropertyFactory.circleStrokeWidth(2.5f),
                PropertyFactory.circleStrokeColor("#FFFFFF")
            )
        )
    }
}
