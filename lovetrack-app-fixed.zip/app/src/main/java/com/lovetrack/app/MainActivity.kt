package com.lovetrack.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.google.firebase.auth.FirebaseAuth
import com.lovetrack.app.feature.auth.LoginScreen
import com.lovetrack.app.feature.auth.RegisterScreen
import com.lovetrack.app.feature.chat.ChatScreen
import com.lovetrack.app.feature.home.HomeScreen
import com.lovetrack.app.feature.map.MapScreen
import com.lovetrack.app.feature.pairing.ConsentScreen
import com.lovetrack.app.feature.pairing.PairingScreen
import com.lovetrack.app.ui.components.LoveTrackBottomNav
import androidx.compose.foundation.isSystemInDarkTheme
import com.lovetrack.app.util.ThemeMode
import com.lovetrack.app.util.ThemeController
import com.lovetrack.app.ui.theme.LoveTrackTheme

// MILESTONE 1 SELESAI — Auth + Pairing + Consent + Presence + Location + Map + Chat + FCM
// Home asli sekarang pakai bottom nav persisten (Home/Map/Chat), mengikuti mockup v3.

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.lovetrack.app.util.ThemeController.init(applicationContext)
        setContent {
            LoveTrackApp()
        }
    }
}

@Composable
fun LoveTrackApp() {
    val navController = rememberNavController()
    val startDestination = if (FirebaseAuth.getInstance().currentUser != null) "home" else "login"
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomNav = currentRoute == "home" || currentRoute == "map" || currentRoute == "chat"

    val savedMode by ThemeController.mode
    val darkTheme = when (savedMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    LoveTrackTheme(darkTheme = darkTheme) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Scaffold(
                bottomBar = {
                    if (showBottomNav) {
                        LoveTrackBottomNav(
                            currentRoute = currentRoute,
                            onNavigate = { route ->
                                if (route != currentRoute) {
                                    navController.navigate(route) {
                                        popUpTo("home") { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = startDestination,
                    modifier = Modifier.padding(innerPadding)
                ) {

                    composable("login") {
                        LoginScreen(
                            onLoginSuccess = {
                                navController.navigate("home") {
                                    popUpTo("login") { inclusive = true }
                                }
                            },
                            onNavigateToRegister = { navController.navigate("register") }
                        )
                    }

                    composable("register") {
                        RegisterScreen(
                            onRegisterSuccess = {
                                navController.navigate("home") {
                                    popUpTo("login") { inclusive = true }
                                }
                            },
                            onNavigateToLogin = { navController.popBackStack() }
                        )
                    }

                    composable("home") {
                        HomeScreen(
                            onNavigateToMap = { navController.navigate("map") },
                            onNavigateToPairing = { navController.navigate("pairing") },
                            onLogout = {
                                navController.navigate("login") {
                                    popUpTo("home") { inclusive = true }
                                }
                            }
                        )
                    }

                    composable("map") {
                        MapScreen()
                    }

                    composable("chat") {
                        ChatScreen()
                    }

                    composable("pairing") {
                        PairingScreen(
                            onPaired = { coupleId ->
                                navController.navigate("consent/$coupleId") {
                                    popUpTo("pairing") { inclusive = true }
                                }
                            }
                        )
                    }

                    composable(
                        route = "consent/{coupleId}",
                        arguments = listOf(navArgument("coupleId") { type = NavType.StringType })
                    ) { backStackEntryArg ->
                        val coupleId = backStackEntryArg.arguments?.getString("coupleId") ?: ""
                        ConsentScreen(
                            coupleId = coupleId,
                            onFinished = {
                                navController.navigate("home") {
                                    popUpTo("home") { inclusive = true }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
