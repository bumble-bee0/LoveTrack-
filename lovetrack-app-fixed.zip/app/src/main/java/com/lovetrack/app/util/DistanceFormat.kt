package com.lovetrack.app.util

import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Jarak garis lurus antar 2 koordinat, dalam kilometer (formula Haversine). */
fun distanceKm(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
    val earthRadiusKm = 6371.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLng = Math.toRadians(lng2 - lng1)
    val a = sin(dLat / 2) * sin(dLat / 2) +
        cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
        sin(dLng / 2) * sin(dLng / 2)
    val c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return earthRadiusKm * c
}

/** Format jarak jadi teks enak dibaca: "850 m" kalau dekat, "1,2 km" kalau jauh. */
fun formatDistance(km: Double): String {
    return if (km < 1.0) {
        "${(km * 1000).toInt()} m"
    } else {
        String.format(Locale("id", "ID"), "%.1f km", km)
    }
}

/** Jumlah hari sejak sebuah Firebase Timestamp (detik) sampai sekarang, minimal 0. */
fun daysSince(startSeconds: Long): Long {
    val nowSeconds = System.currentTimeMillis() / 1000
    val diff = (nowSeconds - startSeconds) / 86400
    return if (diff < 0) 0 else diff
}
