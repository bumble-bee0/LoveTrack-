package com.lovetrack.app.ui.theme

import androidx.compose.ui.graphics.Color

// ====== Palet resmi baru (mengikuti mockup "exact-screens" — ungu/pink, light+dark) ======
// Menggantikan palet Indigo/Pink lama (v3). Tidak dipakai lagi kecuali disebut eksplisit.

// Brand utama — ungu
val LTPrimary = Color(0xFF6C5CE7)
val LTPrimaryDark = Color(0xFF4B3F9E)

// Aksen hangat — pink/rose (dipakai di tombol Send Love, heart icon, dsb)
val LTPink = Color(0xFFF0568C)
val LTPinkDark = Color(0xFFD63E73)

// ---- Light mode ----
val LTBackgroundLight = Color(0xFFF6F2FA) // lavender sangat muda, bukan putih dingin
val LTSurfaceLight = Color(0xFFFFFFFF)
val LTTextPrimaryLight = Color(0xFF191622)
val LTTextSecondaryLight = Color(0xFF716B79)
val LTBorderLight = Color(0xFFE5DFEB)

// ---- Dark mode ----
val LTBackgroundDark = Color(0xFF14101B)
val LTSurfaceDark = Color(0xFF211C2E)
val LTTextPrimaryDark = Color(0xFFF3F0F7)
val LTTextSecondaryDark = Color(0xFFB6AEC2)
val LTBorderDark = Color(0xFF352E42)

// ---- Status ----
val LTWarning = Color(0xFFD99A5B)
val LTError = Color(0xFFC96767)

// Dekorasi lembut buat gradient kartu "Together for X days" dan blob header
val LTGradientStart = LTPrimary
val LTGradientEnd = LTPink
