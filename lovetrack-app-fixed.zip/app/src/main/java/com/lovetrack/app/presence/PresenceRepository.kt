package com.lovetrack.app.presence

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.lovetrack.app.util.awaitResult

data class PresenceData(
    val isOnline: Boolean = false,
    val lastSeen: Timestamp? = null
)

/**
 * Presence disimpan di Firestore (bukan Realtime Database terpisah, sesuai
 * kesepakatan — biar cuma 1 sistem database yang perlu dipelajari/dipelihara).
 *
 * Catatan penting: "isOnline = true" itu artinya APLIKASINYA sedang aktif,
 * BUKAN jaminan orangnya sedang pegang HP. Ini indikator aktivitas app,
 * bukan klaim mutlak.
 */
class PresenceRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    suspend fun setOnline() {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users").document(uid)
            .set(mapOf("isOnline" to true), SetOptions.merge())
            .awaitResult()
    }

    suspend fun setOffline() {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users").document(uid)
            .set(
                mapOf(
                    "isOnline" to false,
                    "lastSeen" to Timestamp.now()
                ),
                SetOptions.merge()
            )
            .awaitResult()
    }

    fun listenPresence(uid: String, onChange: (PresenceData) -> Unit): ListenerRegistration {
        return db.collection("users").document(uid)
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null && snapshot.exists()) {
                    onChange(
                        PresenceData(
                            isOnline = snapshot.getBoolean("isOnline") ?: false,
                            lastSeen = snapshot.getTimestamp("lastSeen")
                        )
                    )
                }
            }
    }
}
