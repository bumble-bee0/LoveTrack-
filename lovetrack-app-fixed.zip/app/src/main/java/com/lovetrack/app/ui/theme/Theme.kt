package com.lovetrack.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Langkah 1 dari penerapan desain baru: light+dark mengikuti pengaturan sistem HP
// secara otomatis (isSystemInDarkTheme). Tidak ada toggle manual dulu — kalau nanti
// diminta toggle manual di dalam app, tinggal tambah state di sini.

private val LightColors = lightColorScheme(
    primary = LTPrimary,
    onPrimary = LTSurfaceLight,
    secondary = LTPink,
    onSecondary = LTSurfaceLight,
    background = LTBackgroundLight,
    onBackground = LTTextPrimaryLight,
    surface = LTSurfaceLight,
    onSurface = LTTextPrimaryLight,
    surfaceVariant = LTBorderLight,
    onSurfaceVariant = LTTextSecondaryLight,
    error = LTError,
    onError = LTSurfaceLight
)

private val DarkColors = darkColorScheme(
    primary = LTPrimary,
    onPrimary = LTSurfaceLight,
    secondary = LTPink,
    onSecondary = LTSurfaceLight,
    background = LTBackgroundDark,
    onBackground = LTTextPrimaryDark,
    surface = LTSurfaceDark,
    onSurface = LTTextPrimaryDark,
    surfaceVariant = LTBorderDark,
    onSurfaceVariant = LTTextSecondaryDark,
    error = LTError,
    onError = LTSurfaceLight
)

// Font custom belum dipasang — masih pakai font bawaan sistem dulu.
private val LTTypography = Typography(
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 18.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp)
)

/**
 * Bungkus seluruh aplikasi dengan tema ini (dipasang sekali di MainActivity).
 * Otomatis ganti palet gelap/terang sesuai pengaturan sistem Android.
 */
/**
 * Bungkus seluruh aplikasi dengan tema ini (dipasang sekali di MainActivity).
 * `darkTheme` dihitung di pemanggil dari ThemeController.mode (Sistem/Terang/Gelap).
 */
@Composable
fun LoveTrackTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = LTTypography,
        content = content
    )
}
