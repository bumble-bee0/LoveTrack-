package com.lovetrack.app.feature.pairing

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class PairingUiState {
    data object Loading : PairingUiState()
    data object Choice : PairingUiState()
    data class HostWaiting(val code: String) : PairingUiState()
    data class HostApprovalNeeded(val code: String, val partnerUid: String) : PairingUiState()
    data class JoinWaitingApproval(val code: String) : PairingUiState()
    data class PairSuccess(val coupleId: String) : PairingUiState()
    data class Error(val message: String) : PairingUiState()
}

class PairingViewModel(
    private val repository: PairingRepository = PairingRepository(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) : ViewModel() {

    private val _uiState = MutableStateFlow<PairingUiState>(PairingUiState.Loading)
    val uiState: StateFlow<PairingUiState> = _uiState

    private var listener: ListenerRegistration? = null

    private val myUid: String
        get() = auth.currentUser?.uid ?: ""

    init {
        checkExistingPairing()
    }

    private fun checkExistingPairing() {
        viewModelScope.launch {
            try {
                val coupleId = repository.getMyCoupleId(myUid)
                _uiState.value = if (coupleId != null) {
                    PairingUiState.PairSuccess(coupleId)
                } else {
                    PairingUiState.Choice
                }
            } catch (e: Exception) {
                _uiState.value = PairingUiState.Error(e.message ?: "Gagal memuat status pairing")
            }
        }
    }

    fun showChoice() {
        _uiState.value = PairingUiState.Choice
    }

    fun startHost() {
        viewModelScope.launch {
            try {
                val code = repository.generateCode(myUid)
                _uiState.value = PairingUiState.HostWaiting(code)
                attachListener(code, isHost = true)
            } catch (e: Exception) {
                _uiState.value = PairingUiState.Error(e.message ?: "Gagal membuat kode")
            }
        }
    }

    fun submitJoinCode(rawCode: String) {
        val code = rawCode.trim().uppercase()
        if (code.length < 4) {
            _uiState.value = PairingUiState.Error("Kode tidak valid")
            return
        }
        viewModelScope.launch {
            try {
                repository.joinWithCode(code, myUid)
                _uiState.value = PairingUiState.JoinWaitingApproval(code)
                attachListener(code, isHost = false)
            } catch (e: Exception) {
                _uiState.value = PairingUiState.Error(e.message ?: "Gagal menghubungkan kode")
            }
        }
    }

    fun approve() {
        val state = _uiState.value
        if (state !is PairingUiState.HostApprovalNeeded) return
        viewModelScope.launch {
            try {
                val coupleId = repository.approveAndCreateCouple(
                    code = state.code,
                    requesterId = myUid,
                    targetUserId = state.partnerUid
                )
                listener?.remove()
                _uiState.value = PairingUiState.PairSuccess(coupleId)
            } catch (e: Exception) {
                _uiState.value = PairingUiState.Error(e.message ?: "Gagal menyetujui pairing")
            }
        }
    }

    private fun attachListener(code: String, isHost: Boolean) {
        listener?.remove()
        listener = repository.listenToPairingRequest(
            code = code,
            onUpdate = { data ->
                if (data == null) return@listenToPairingRequest
                when (data.status) {
                    "awaiting_approval" -> {
                        if (isHost && data.targetUserId != null) {
                            _uiState.value = PairingUiState.HostApprovalNeeded(code, data.targetUserId)
                        }
                    }
                    "approved" -> {
                        val coupleId = data.coupleId
                        if (!isHost && coupleId != null) {
                            viewModelScope.launch {
                                try {
                                    repository.confirmOwnCoupleId(myUid, coupleId)
                                    listener?.remove()
                                    _uiState.value = PairingUiState.PairSuccess(coupleId)
                                } catch (e: Exception) {
                                    _uiState.value = PairingUiState.Error(
                                        e.message ?: "Gagal menyelesaikan pairing"
                                    )
                                }
                            }
                        }
                    }
                }
            },
            onError = { e ->
                _uiState.value = PairingUiState.Error(e.message ?: "Terjadi kesalahan koneksi")
            }
        )
    }

    override fun onCleared() {
        super.onCleared()
        listener?.remove()
    }
}
