package com.lovetrack.app.feature.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.lovetrack.app.data.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * State layar Auth. UI (Composable) tinggal "amati" state ini, tidak perlu tau
 * detail proses Firebase-nya seperti apa.
 */
sealed class AuthUiState {
    data object Idle : AuthUiState()
    data object Loading : AuthUiState()
    data object Success : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel(
    private val repository: AuthRepository = AuthRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.value = AuthUiState.Error("Email dan password wajib diisi")
            return
        }
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            try {
                repository.login(email, password)
                _uiState.value = AuthUiState.Success
            } catch (e: Exception) {
                _uiState.value = AuthUiState.Error(mapErrorToMessage(e))
            }
        }
    }

    fun register(email: String, password: String, confirmPassword: String) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.value = AuthUiState.Error("Email dan password wajib diisi")
            return
        }
        if (password != confirmPassword) {
            _uiState.value = AuthUiState.Error("Konfirmasi password tidak cocok")
            return
        }
        if (password.length < 6) {
            _uiState.value = AuthUiState.Error("Password minimal 6 karakter")
            return
        }
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            try {
                repository.register(email, password)
                _uiState.value = AuthUiState.Success
            } catch (e: Exception) {
                _uiState.value = AuthUiState.Error(mapErrorToMessage(e))
            }
        }
    }

    /** Dipanggil setelah UI selesai bereaksi ke Success/Error, biar tidak ke-trigger 2x. */
    fun resetState() {
        _uiState.value = AuthUiState.Idle
    }

    /**
     * Firebase ngasih exception teknis dalam bahasa Inggris — kita terjemahkan
     * ke pesan yang lebih manusiawi buat ditampilkan ke user.
     */
    private fun mapErrorToMessage(e: Exception): String {
        return when (e) {
            is FirebaseAuthInvalidUserException -> "Akun dengan email ini tidak ditemukan"
            is FirebaseAuthInvalidCredentialsException -> "Email atau password salah"
            is FirebaseAuthUserCollisionException -> "Email ini sudah terdaftar, coba login"
            is FirebaseAuthWeakPasswordException -> "Password terlalu lemah, gunakan minimal 6 karakter"
            else -> e.message ?: "Terjadi kesalahan, coba lagi"
        }
    }
}
