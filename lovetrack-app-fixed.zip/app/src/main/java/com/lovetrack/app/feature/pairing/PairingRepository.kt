package com.lovetrack.app.feature.pairing

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.lovetrack.app.util.awaitResult

data class PairingRequestData(
    val requesterId: String = "",
    val targetUserId: String? = null,
    val status: String = "",
    val coupleId: String? = null,
    val expiresAt: Timestamp? = null
)

/**
 * Alur pairing (sesuai konsep yang sudah dikunci):
 * NO_PAIR -> generate/kode dibuat -> partner input kode (awaiting_approval)
 * -> host approve (couple dibuat, status approved) -> masing2 update coupleId sendiri
 */
class PairingRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val codeChars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // tanpa 0/O/1/I biar gak ambigu

    private fun randomCode(): String = (1..6).map { codeChars.random() }.joinToString("")

    suspend fun getMyCoupleId(uid: String): String? {
        val snapshot = db.collection("users").document(uid).get().awaitResult()
        return snapshot.getString("coupleId")
    }

    /** Bikin kode unik. Kalau kebetulan tabrakan sama kode lain yang masih aktif, coba lagi. */
    suspend fun generateCode(requesterId: String): String {
        repeat(5) {
            val code = randomCode()
            val docRef = db.collection("pairing_requests").document(code)
            val existing = docRef.get().awaitResult()
            if (!existing.exists()) {
                val expiresAt = Timestamp(Timestamp.now().seconds + 15 * 60, 0)
                val data = hashMapOf(
                    "requesterId" to requesterId,
                    "targetUserId" to null,
                    "status" to "pending",
                    "coupleId" to null,
                    "expiresAt" to expiresAt,
                    "createdAt" to Timestamp.now()
                )
                docRef.set(data).awaitResult()
                return code
            }
        }
        throw Exception("Gagal membuat kode, coba lagi")
    }

    fun listenToPairingRequest(
        code: String,
        onUpdate: (PairingRequestData?) -> Unit,
        onError: (Exception) -> Unit
    ): ListenerRegistration {
        return db.collection("pairing_requests").document(code)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error)
                    return@addSnapshotListener
                }
                if (snapshot == null || !snapshot.exists()) {
                    onUpdate(null)
                    return@addSnapshotListener
                }
                onUpdate(
                    PairingRequestData(
                        requesterId = snapshot.getString("requesterId") ?: "",
                        targetUserId = snapshot.getString("targetUserId"),
                        status = snapshot.getString("status") ?: "",
                        coupleId = snapshot.getString("coupleId"),
                        expiresAt = snapshot.getTimestamp("expiresAt")
                    )
                )
            }
    }

    suspend fun joinWithCode(code: String, myUid: String) {
        val docRef = db.collection("pairing_requests").document(code)
        val snapshot = docRef.get().awaitResult()

        if (!snapshot.exists()) throw Exception("Kode tidak ditemukan")

        val status = snapshot.getString("status")
        val expiresAt = snapshot.getTimestamp("expiresAt")
        val requesterId = snapshot.getString("requesterId")

        if (status != "pending") throw Exception("Kode sudah tidak berlaku")
        if (expiresAt != null && expiresAt.seconds < Timestamp.now().seconds) {
            throw Exception("Kode sudah kedaluwarsa")
        }
        if (requesterId == myUid) throw Exception("Tidak bisa memakai kode buatan sendiri")

        docRef.update(
            mapOf(
                "targetUserId" to myUid,
                "status" to "awaiting_approval"
            )
        ).awaitResult()
    }

    /** Dipanggil HOST (pembuat kode) setelah menekan tombol Terima. */
    suspend fun approveAndCreateCouple(code: String, requesterId: String, targetUserId: String): String {
        val coupleRef = db.collection("couples").document()
        val coupleId = coupleRef.id

        coupleRef.set(
            hashMapOf(
                "user1" to requesterId,
                "user2" to targetUserId,
                "status" to "pending_consent",
                "pairedAt" to Timestamp.now()
            )
        ).awaitResult()

        // Tiap user cuma boleh nulis dokumen users/{uid} miliknya sendiri (sesuai Security Rules).
        // Pakai set+merge (bukan update) biar tidak error kalau dokumennya belum pernah dibuat.
        db.collection("users").document(requesterId)
            .set(mapOf("coupleId" to coupleId), com.google.firebase.firestore.SetOptions.merge())
            .awaitResult()

        db.collection("pairing_requests").document(code)
            .update(mapOf("status" to "approved", "coupleId" to coupleId))
            .awaitResult()

        return coupleId
    }

    /** Dipanggil partner (yang input kode) begitu lihat status "approved". */
    suspend fun confirmOwnCoupleId(myUid: String, coupleId: String) {
        db.collection("users").document(myUid)
            .set(mapOf("coupleId" to coupleId), com.google.firebase.firestore.SetOptions.merge())
            .awaitResult()
    }
}
