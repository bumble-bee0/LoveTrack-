package com.lovetrack.app.feature.pairing

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun PairingScreen(
    onPaired: (coupleId: String) -> Unit,
    viewModel: PairingViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState) {
        val state = uiState
        if (state is PairingUiState.PairSuccess) {
            onPaired(state.coupleId)
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        when (val state = uiState) {
            is PairingUiState.Loading -> CircularProgressIndicator()

            is PairingUiState.Choice -> ChoiceContent(
                onHost = { viewModel.startHost() },
                onJoin = { code -> viewModel.submitJoinCode(code) }
            )

            is PairingUiState.HostWaiting -> HostWaitingContent(code = state.code)

            is PairingUiState.HostApprovalNeeded -> ApprovalContent(
                onApprove = { viewModel.approve() }
            )

            is PairingUiState.JoinWaitingApproval -> JoinWaitingContent(code = state.code)

            is PairingUiState.PairSuccess -> CircularProgressIndicator() // sekejap, langsung pindah lewat LaunchedEffect

            is PairingUiState.Error -> ErrorContent(
                message = state.message,
                onRetry = { viewModel.showChoice() }
            )
        }
    }
}

@Composable
private fun ChoiceContent(onHost: () -> Unit, onJoin: (String) -> Unit) {
    var showJoinInput by remember { mutableStateOf(false) }
    var codeInput by remember { mutableStateOf("") }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Hubungkan dengan pasanganmu", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Belum ada pasangan yang terhubung ke akunmu",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer24()

        if (!showJoinInput) {
            Button(onClick = onHost, modifier = Modifier.fillMaxWidth()) {
                Text("Buat Kode Undangan")
            }
            OutlinedButton(
                onClick = { showJoinInput = true },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) {
                Text("Punya Kode? Masukkan di Sini")
            }
        } else {
            OutlinedTextField(
                value = codeInput,
                onValueChange = { codeInput = it },
                label = { Text("Kode dari pasangan") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { onJoin(codeInput) },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) {
                Text("Hubungkan")
            }
            TextButton(onClick = { showJoinInput = false }) {
                Text("Kembali")
            }
        }
    }
}

@Composable
private fun HostWaitingContent(code: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Bagikan kode ini ke pasanganmu", style = MaterialTheme.typography.titleMedium)
        Spacer16()
        Text(text = code, style = MaterialTheme.typography.displaySmall)
        Spacer16()
        Text("Kode berlaku 15 menit", style = MaterialTheme.typography.bodySmall)
        Spacer24()
        CircularProgressIndicator(modifier = Modifier.size(24.dp))
        Text(
            "Menunggu pasangan memasukkan kode...",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
private fun ApprovalContent(onApprove: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Pasanganmu ingin terhubung", style = MaterialTheme.typography.titleMedium)
        Text(
            "Setujui untuk mulai berbagi lokasi & status dengannya",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer24()
        Button(onClick = onApprove, modifier = Modifier.fillMaxWidth()) {
            Text("Terima")
        }
    }
}

@Composable
private fun JoinWaitingContent(code: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Permintaan terkirim ❤️", style = MaterialTheme.typography.titleMedium)
        Text(
            "Minta pasanganmu membuka aplikasi untuk menyetujui",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer24()
        CircularProgressIndicator(modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun ErrorContent(message: String, onRetry: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(message, color = MaterialTheme.colorScheme.error)
        Spacer16()
        Button(onClick = onRetry) {
            Text("Coba Lagi")
        }
    }
}

@Composable
private fun Spacer16() = androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(16.dp))

@Composable
private fun Spacer24() = androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(24.dp))
