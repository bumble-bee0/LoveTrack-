package com.lovetrack.app.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ChatViewModel(
    private val coupleId: String,
    private val repository: ChatRepository = ChatRepository(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _sendError = MutableStateFlow<String?>(null)
    val sendError: StateFlow<String?> = _sendError

    private var listener: ListenerRegistration? = null

    val myUid: String
        get() = auth.currentUser?.uid ?: ""

    init {
        listener = repository.listenMessages(coupleId) { msgs ->
            _messages.value = msgs
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            try {
                repository.sendMessage(coupleId, myUid, text.trim())
                _sendError.value = null
            } catch (e: Exception) {
                _sendError.value = e.message ?: "Gagal mengirim pesan"
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        listener?.remove()
    }
}

/** Dibutuhkan karena ChatViewModel butuh parameter coupleId di constructor-nya. */
class ChatViewModelFactory(private val coupleId: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return ChatViewModel(coupleId) as T
    }
}
