package com.lovetrack.app.feature.map

object MapConfig {
    // Key MapTiler punya project LoveTrack. Untuk prototipe/testing ini aman
    // ditaruh langsung di kode (bukan credential rahasia tingkat tinggi,
    // beda kasusnya dengan Firebase service account key).
    const val MAPTILER_KEY = "2TyBpB44vxw28Buko8JZ"
    const val STYLE_URL = "https://api.maptiler.com/maps/streets/style.json?key=$MAPTILER_KEY"
}
