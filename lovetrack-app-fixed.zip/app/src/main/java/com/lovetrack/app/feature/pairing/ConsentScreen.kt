package com.lovetrack.app.feature.pairing

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun ConsentScreen(
    coupleId: String,
    onFinished: () -> Unit,
    viewModel: ConsentViewModel = viewModel(factory = ConsentViewModelFactory(coupleId))
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState) {
        if (uiState is ConsentUiState.Done) {
            onFinished()
        }
    }

    var shareLocation by remember { mutableStateOf(true) }
    var shareStatus by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        when (val state = uiState) {
            is ConsentUiState.Loading -> CircularProgressIndicator()

            is ConsentUiState.Form -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "Pilih informasi yang ingin kamu bagikan",
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    "Pasanganmu memilih sendiri apa yang dia bagikan, tidak otomatis sama",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                )

                ConsentRow(
                    label = "📍 Lokasi saya",
                    checked = shareLocation,
                    onCheckedChange = { shareLocation = it }
                )
                ConsentRow(
                    label = "💬 Status online saya",
                    checked = shareStatus,
                    onCheckedChange = { shareStatus = it }
                )

                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { viewModel.submit(shareLocation, shareStatus) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Lanjutkan")
                }
            }

            is ConsentUiState.WaitingPartner -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Menunggu pasangan menyetujui...", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(16.dp))
                CircularProgressIndicator()
            }

            is ConsentUiState.Done -> Text("Terhubung! ❤️", style = MaterialTheme.typography.headlineSmall)

            is ConsentUiState.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun ConsentRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
