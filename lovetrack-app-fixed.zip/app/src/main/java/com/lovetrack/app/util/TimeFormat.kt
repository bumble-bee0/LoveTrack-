package com.lovetrack.app.util

/**
 * Format jumlah detik jadi teks yang mudah dibaca, contoh:
 * "baru saja", "5 menit lalu", "5 jam 2 menit lalu", "10 hari 5 jam 2 menit lalu"
 */
fun formatDurationAgo(totalSeconds: Long): String {
    if (totalSeconds < 60) return "baru saja"

    val minutes = (totalSeconds / 60) % 60
    val hours = (totalSeconds / 3600) % 24
    val days = totalSeconds / 86400

    val parts = mutableListOf<String>()
    if (days > 0) parts.add("$days hari")
    if (hours > 0) parts.add("$hours jam")
    if (minutes > 0 || parts.isEmpty()) parts.add("$minutes menit")

    return parts.joinToString(" ") + " lalu"
}
