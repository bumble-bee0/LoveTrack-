package com.lovetrack.app.feature.home

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.lovetrack.app.location.LocationData
import com.lovetrack.app.location.LocationRepository
import com.lovetrack.app.location.LocationUiState
import com.lovetrack.app.location.LocationViewModel
import com.lovetrack.app.notify.FcmTokenRepository
import com.lovetrack.app.notify.NotifyRepository
import com.lovetrack.app.presence.PresenceRepository
import com.lovetrack.app.ui.theme.LTGradientEnd
import com.lovetrack.app.ui.theme.LTGradientStart
import com.lovetrack.app.util.awaitResult
import com.lovetrack.app.util.daysSince
import com.lovetrack.app.util.distanceKm
import com.lovetrack.app.util.formatDistance
import com.lovetrack.app.util.formatDurationAgo
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Home asli (menggantikan HomePlaceholderScreen) — mengikuti mockup v3:
 * greeting + together-counter, distance card, presence card, tombol
 * "Thinking of You". Navigasi Map/Chat dipindah ke bottom nav (lihat MainActivity).
 */
@Composable
fun HomeScreen(
    onNavigateToMap: () -> Unit,
    onNavigateToPairing: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val uid = FirebaseAuth.getInstance().currentUser?.uid
    val email = FirebaseAuth.getInstance().currentUser?.email ?: "-"
    val displayName = remember(email) {
        email.substringBefore("@").replaceFirstChar { it.uppercase() }
    }

    var loading by remember { mutableStateOf(true) }
    var coupleId by remember { mutableStateOf<String?>(null) }
    var partnerUid by remember { mutableStateOf<String?>(null) }
    var pairedAtSeconds by remember { mutableStateOf<Long?>(null) }

    var myLocation by remember { mutableStateOf<LocationData?>(null) }
    var partnerLocation by remember { mutableStateOf<LocationData?>(null) }
    var partnerPresenceText by remember { mutableStateOf("Belum ada info") }

    var notifyStatusText by remember { mutableStateOf("") }
    var sendingNotify by remember { mutableStateOf(false) }

    val locationViewModel: LocationViewModel = viewModel()
    val locationState by locationViewModel.uiState.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) locationViewModel.shareLocation(context) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* diterima atau ditolak, tidak perlu aksi khusus */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun onShareLocationClick() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) {
            locationViewModel.shareLocation(context)
        } else {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    fun onSendThinkingOfYouClick() {
        val cId = coupleId
        val myUid = uid
        if (cId == null || myUid == null) return
        sendingNotify = true
        notifyStatusText = ""
        coroutineScope.launch {
            val result = NotifyRepository().sendThinkingOfYou(cId, myUid, displayName)
            sendingNotify = false
            notifyStatusText = if (result.isSuccess) "Terkirim 💌" else "Gagal mengirim, coba lagi"
        }
    }

    LaunchedEffect(uid) {
        if (uid != null) {
            try {
                val userSnap = FirebaseFirestore.getInstance()
                    .collection("users").document(uid).get().awaitResult()
                val cId = userSnap.getString("coupleId")
                coupleId = cId

                if (cId != null) {
                    val coupleSnap = FirebaseFirestore.getInstance()
                        .collection("couples").document(cId).get().awaitResult()
                    val user1 = coupleSnap.getString("user1")
                    val user2 = coupleSnap.getString("user2")
                    partnerUid = if (user1 == uid) user2 else user1
                    pairedAtSeconds = coupleSnap.getTimestamp("pairedAt")?.seconds
                }
            } catch (_: Exception) {
                coupleId = null
            }

            try {
                FcmTokenRepository().registerTokenForUser(uid)
            } catch (_: Exception) {
                // Tidak fatal — dicoba lagi lain kali app dibuka
            }
        }
        loading = false
    }

    DisposableEffect(uid) {
        val listener = uid?.let {
            LocationRepository().listenLocation(it) { loc -> myLocation = loc }
        }
        onDispose { listener?.remove() }
    }

    DisposableEffect(partnerUid) {
        val pUid = partnerUid
        val presenceListener = pUid?.let {
            PresenceRepository().listenPresence(it) { presence ->
                partnerPresenceText = when {
                    presence.isOnline -> "🟢 Online"
                    presence.lastSeen != null -> {
                        val secondsAgo = Timestamp.now().seconds - presence.lastSeen.seconds
                        "Terakhir dilihat ${formatDurationAgo(secondsAgo)}"
                    }
                    else -> "Belum ada info"
                }
            }
        }
        val locationListener = pUid?.let {
            LocationRepository().listenLocation(it) { loc -> partnerLocation = loc }
        }
        onDispose {
            presenceListener?.remove()
            locationListener?.remove()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        HomeHeroBlob()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = greetingText(displayName),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButtonKeluar(onClick = {
                    FirebaseAuth.getInstance().signOut()
                    onLogout()
                })
            }

            if (loading) {
                Box(Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (coupleId == null) {
                Spacer(modifier = Modifier.height(32.dp))
                Text(
                    "Belum terhubung dengan pasangan",
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    "Buat atau masukkan kode undangan dulu untuk mulai terhubung",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
                Button(
                    onClick = onNavigateToPairing,
                    modifier = Modifier.padding(top = 16.dp)
                ) {
                    Text("Hubungkan Sekarang")
                }
            } else {
                // Together counter
                val days = pairedAtSeconds?.let { daysSince(it) }
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Bersama selama",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = days?.toString() ?: "-",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 46.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Text(
                        "hari · terus bertambah ✦",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Distance card
                val distanceText = if (myLocation != null && partnerLocation != null) {
                    formatDistance(
                        distanceKm(
                            myLocation!!.lat, myLocation!!.lng,
                            partnerLocation!!.lat, partnerLocation!!.lng
                        )
                    )
                } else {
                    "Belum diketahui"
                }
                LoveTrackCard {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            InitialAvatar(letter = displayName.take(1), isPrimary = true)
                            DottedConnectorLine()
                            InitialAvatar(letter = "P", isPrimary = false)
                        }
                        Text(
                            text = distanceText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                        Button(
                            onClick = onNavigateToMap,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.background,
                                contentColor = MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(100),
                            modifier = Modifier.padding(top = 10.dp)
                        ) {
                            Text("🗺️ Buka Peta")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Presence card
                LoveTrackCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        InitialAvatar(letter = "P", isPrimary = false, size = 46.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Pasanganmu", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                partnerPresenceText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Thinking of you button
                Button(
                    onClick = { onSendThinkingOfYouClick() },
                    enabled = !sendingNotify,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    if (sendingNotify) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text("💌  Thinking of You", fontWeight = FontWeight.Bold)
                    }
                }
                if (notifyStatusText.isNotEmpty()) {
                    Text(
                        notifyStatusText,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Manual location share (fitur lama, tetap dipertahankan)
                Button(
                    onClick = { onShareLocationClick() },
                    enabled = locationState !is LocationUiState.Loading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (locationState is LocationUiState.Loading) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp))
                    } else {
                        Text("Bagikan Lokasi Saya")
                    }
                }

                when (val state = locationState) {
                    is LocationUiState.Success -> {
                        Text(
                            "Lokasimu terkirim: ${state.lat}, ${state.lng} (±${state.accuracy.toInt()}m)",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    is LocationUiState.Error -> {
                        Text(
                            state.message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    else -> {}
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun IconButtonKeluar(onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text("Keluar", color = MaterialTheme.colorScheme.onSurface)
    }
}

private fun greetingText(name: String): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val time = when {
        hour < 10 -> "pagi"
        hour < 15 -> "siang"
        hour < 18 -> "sore"
        else -> "malam"
    }
    return "Selamat $time, $name"
}

@Composable
private fun HomeHeroBlob() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        LTGradientStart.copy(alpha = 0.25f),
                        LTGradientEnd.copy(alpha = 0.15f),
                        Color.Transparent
                    )
                )
            )
    )
}

@Composable
private fun LoveTrackCard(content: @Composable () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
        shadowElevation = 3.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(modifier = Modifier.padding(16.dp)) {
            content()
        }
    }
}

@Composable
private fun InitialAvatar(letter: String, isPrimary: Boolean, size: Dp = 44.dp) {
    val brush = if (isPrimary) {
        Brush.linearGradient(
            listOf(
                MaterialTheme.colorScheme.primary,
                MaterialTheme.colorScheme.primary.copy(alpha = 0.75f)
            )
        )
    } else {
        Brush.linearGradient(
            listOf(
                MaterialTheme.colorScheme.secondary,
                MaterialTheme.colorScheme.secondary.copy(alpha = 0.75f)
            )
        )
    }
    Box(
        modifier = Modifier
            .size(size)
            .background(brush = brush, shape = CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(letter.uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DottedConnectorLine() {
    Box(
        modifier = Modifier
            .padding(horizontal = 10.dp)
            .width(32.dp)
            .height(2.dp)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
    )
}
