package com.lovetrack.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Logo "Two Dots Connected" — dua lingkaran (ungu + pink) terhubung garis lengkung,
 * sesuai identitas brand LoveTrack yang sudah dikunci sejak awal proyek.
 */
@Composable
fun LoveTrackLogo(size: androidx.compose.ui.unit.Dp = 72.dp) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    Box(modifier = Modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val r = this.size.minDimension / 4.2f
            val leftCenter = Offset(this.size.width * 0.33f, this.size.height * 0.55f)
            val rightCenter = Offset(this.size.width * 0.67f, this.size.height * 0.45f)

            drawLine(
                brush = Brush.linearGradient(listOf(primary, secondary)),
                start = leftCenter,
                end = rightCenter,
                strokeWidth = r * 0.5f,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
            drawCircle(color = primary, radius = r, center = leftCenter)
            drawCircle(color = secondary, radius = r, center = rightCenter)
        }
    }
}
