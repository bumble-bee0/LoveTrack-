package com.lovetrack.app

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.lovetrack.app.location.AutoLocationScheduler
import com.lovetrack.app.presence.AppPresenceObserver
import org.maplibre.android.MapLibre

class LoveTrackApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        MapLibre.getInstance(this)
        val lifecycle = ProcessLifecycleOwner.get().lifecycle
        lifecycle.addObserver(AppPresenceObserver())
        lifecycle.addObserver(AutoLocationScheduler(this))
    }
}
