package com.lovetrack.app.util

import android.content.Context
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf

/**
 * Pilihan tema manual milik user. Defaultnya ikut sistem HP.
 *
 * UI untuk ganti pilihan ini SEMENTARA ditaruh sebagai ikon kecil di LoginScreen,
 * sampai layar More/Pengaturan resmi dibangun (Langkah 8) — pindahin composable-nya
 * ke sana nanti, logika di file ini tidak perlu diubah.
 *
 * `mode` adalah Compose State, jadi begitu di-set, semua layar yang lagi kebuka
 * langsung ganti tema tanpa perlu restart app.
 */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

private const val PREFS_NAME = "lovetrack_prefs"
private const val KEY_THEME_MODE = "theme_mode"

object ThemeController {
    private val _mode = mutableStateOf(ThemeMode.SYSTEM)
    val mode: State<ThemeMode> = _mode

    /** Panggil sekali di MainActivity.onCreate, sebelum setContent. */
    fun init(context: Context) {
        val stored = prefs(context).getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name)
        _mode.value = try {
            ThemeMode.valueOf(stored ?: ThemeMode.SYSTEM.name)
        } catch (_: IllegalArgumentException) {
            ThemeMode.SYSTEM
        }
    }

    fun setMode(context: Context, mode: ThemeMode) {
        _mode.value = mode
        prefs(context).edit().putString(KEY_THEME_MODE, mode.name).apply()
    }

    /** Geser ke pilihan berikutnya: Sistem -> Terang -> Gelap -> Sistem -> ... */
    fun cycle(context: Context) {
        val next = when (_mode.value) {
            ThemeMode.SYSTEM -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.DARK
            ThemeMode.DARK -> ThemeMode.SYSTEM
        }
        setMode(context, next)
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
