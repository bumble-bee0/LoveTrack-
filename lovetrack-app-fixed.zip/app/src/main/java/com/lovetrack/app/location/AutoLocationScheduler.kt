package com.lovetrack.app.location

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * TINGKAT 2 — otomatis, TAPI HANYA selama app dibuka (foreground).
 *
 * Begitu app ditutup/di-minimize (ProcessLifecycleOwner onStop), loop ini
 * langsung berhenti. Ini BUKAN background service, BUKAN tracking yang jalan
 * walau app ditutup atau layar mati — itu Tingkat 3 yang masih ditunda ke
 * Fase 2 sesuai kesepakatan (butuh foreground service + notifikasi permanen +
 * izin khusus Android yang jauh lebih kompleks).
 *
 * Catatan: izin lokasi tetap harus di-grant minimal sekali lewat tombol manual
 * di UI (Activity) — observer ini cuma bisa CEK izin, tidak bisa MEMINTA izin,
 * karena bukan dijalankan dari Activity.
 */
class AutoLocationScheduler(
    private val appContext: Context,
    private val repository: LocationRepository = LocationRepository(),
    private val intervalMillis: Long = 3 * 60 * 1000L // 3 menit
) : DefaultLifecycleObserver {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var job: Job? = null

    override fun onStart(owner: LifecycleOwner) {
        job?.cancel()
        job = scope.launch {
            while (true) {
                shareIfPermitted()
                delay(intervalMillis)
            }
        }
    }

    override fun onStop(owner: LifecycleOwner) {
        job?.cancel()
        job = null
    }

    private suspend fun shareIfPermitted() {
        val hasPermission = ContextCompat.checkSelfPermission(
            appContext, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasPermission) return

        try {
            val location = repository.getCurrentLocationOneShot(appContext)
            repository.shareMyLocation(location.latitude, location.longitude, location.accuracy)
        } catch (_: Exception) {
            // Gagal diam-diam (misal GPS lagi nggak fix), dicoba lagi di interval berikutnya.
            // Bukan fitur kritis, jangan sampai bikin app crash.
        }
    }
}
