package com.lovetrack.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.lovetrack.app.util.awaitResult
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Jembatan ke Firebase Authentication + memastikan dokumen users/{uid} di Firestore
 * selalu ada (dibutuhkan fitur Pairing dkk).
 */
class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    val currentUserEmail: String?
        get() = auth.currentUser?.email

    fun isLoggedIn(): Boolean = auth.currentUser != null

    suspend fun register(email: String, password: String) {
        suspendCancellableCoroutine<Unit> { cont ->
            auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener { cont.resume(Unit) }
                .addOnFailureListener { e -> cont.resumeWithException(e) }
        }
        ensureUserDocument(email)
    }

    suspend fun login(email: String, password: String) {
        suspendCancellableCoroutine<Unit> { cont ->
            auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { cont.resume(Unit) }
                .addOnFailureListener { e -> cont.resumeWithException(e) }
        }
        // Self-heal: akun yang dibuat SEBELUM perbaikan ini mungkin belum punya
        // dokumen users/{uid}. Pastikan selalu ada setiap kali login.
        ensureUserDocument(email)
    }

    fun logout() {
        auth.signOut()
    }

    /**
     * Pakai set+merge (BUKAN update) biar:
     * 1. Tidak error kalau dokumennya belum pernah dibuat sama sekali
     * 2. Tidak menimpa field lain (misal coupleId) kalau dokumennya sudah ada
     */
    private suspend fun ensureUserDocument(email: String) {
        val uid = auth.currentUser?.uid ?: return
        firestore.collection("users").document(uid)
            .set(mapOf("email" to email), SetOptions.merge())
            .awaitResult()
    }
}
