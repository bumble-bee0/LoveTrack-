package com.lovetrack.app.location

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class LocationUiState {
    data object Idle : LocationUiState()
    data object Loading : LocationUiState()
    data class Success(val lat: Double, val lng: Double, val accuracy: Float) : LocationUiState()
    data class Error(val message: String) : LocationUiState()
}

class LocationViewModel(
    private val repository: LocationRepository = LocationRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow<LocationUiState>(LocationUiState.Idle)
    val uiState: StateFlow<LocationUiState> = _uiState

    fun shareLocation(context: Context) {
        _uiState.value = LocationUiState.Loading
        viewModelScope.launch {
            try {
                val location = repository.getCurrentLocationOneShot(context)
                repository.shareMyLocation(location.latitude, location.longitude, location.accuracy)
                _uiState.value = LocationUiState.Success(
                    lat = location.latitude,
                    lng = location.longitude,
                    accuracy = location.accuracy
                )
            } catch (e: Exception) {
                _uiState.value = LocationUiState.Error(e.message ?: "Gagal membagikan lokasi")
            }
        }
    }

    fun resetState() {
        _uiState.value = LocationUiState.Idle
    }
}
