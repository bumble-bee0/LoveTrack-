package com.lovetrack.app.notify

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Jembatan ke Cloudflare Worker "lovetrack-notify". Firebase Admin credential
 * TIDAK PERNAH ada di APK — semua proses ambil access token & kirim FCM
 * terjadi di sisi Worker. APK cuma kirim POST dengan header rahasia sederhana.
 *
 * APP_SECRET di sini HARUS SAMA PERSIS dengan secret APP_SECRET yang
 * disimpan di Cloudflare Worker Settings > Variables and Secrets.
 */
class NotifyRepository(
    private val workerUrl: String = "https://lovetrack-notify.clipvikmusic.workers.dev/",
    private val appSecret: String = "lovetrack2026rahasia"
) {
    suspend fun sendThinkingOfYou(coupleId: String, fromUid: String, fromName: String?): Result<Unit> {
        return withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(workerUrl)
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 10_000
                    readTimeout = 10_000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("X-App-Secret", appSecret)
                }

                val body = JSONObject().apply {
                    put("coupleId", coupleId)
                    put("fromUid", fromUid)
                    if (fromName != null) put("fromName", fromName)
                }

                connection.outputStream.use { it.write(body.toString().toByteArray()) }

                val code = connection.responseCode
                if (code in 200..299) {
                    Result.success(Unit)
                } else {
                    Result.failure(Exception("Worker merespons kode $code"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                connection?.disconnect()
            }
        }
    }
}
