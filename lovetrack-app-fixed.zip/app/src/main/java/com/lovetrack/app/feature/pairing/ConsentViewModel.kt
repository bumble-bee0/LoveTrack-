package com.lovetrack.app.feature.pairing

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class ConsentUiState {
    data object Loading : ConsentUiState()
    data object Form : ConsentUiState()
    data object WaitingPartner : ConsentUiState()
    data object Done : ConsentUiState()
    data class Error(val message: String) : ConsentUiState()
}

class ConsentViewModel(
    private val coupleId: String,
    private val repository: ConsentRepository = ConsentRepository(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) : ViewModel() {

    private val _uiState = MutableStateFlow<ConsentUiState>(ConsentUiState.Loading)
    val uiState: StateFlow<ConsentUiState> = _uiState

    private var partnerUid: String = ""
    private var listener: ListenerRegistration? = null

    private val myUid: String
        get() = auth.currentUser?.uid ?: ""

    init {
        viewModelScope.launch {
            try {
                partnerUid = repository.getPartnerUid(coupleId, myUid)
                val already = repository.hasConsented(coupleId, myUid)
                _uiState.value = if (already) ConsentUiState.WaitingPartner else ConsentUiState.Form
                if (already) attachPartnerListener()
            } catch (e: Exception) {
                _uiState.value = ConsentUiState.Error(e.message ?: "Gagal memuat data pairing")
            }
        }
    }

    fun submit(locationSharing: Boolean, statusSharing: Boolean) {
        viewModelScope.launch {
            try {
                repository.submitConsent(coupleId, myUid, locationSharing, statusSharing)
                _uiState.value = ConsentUiState.WaitingPartner
                attachPartnerListener()
            } catch (e: Exception) {
                _uiState.value = ConsentUiState.Error(e.message ?: "Gagal menyimpan persetujuan")
            }
        }
    }

    private fun attachPartnerListener() {
        listener?.remove()
        listener = repository.listenPartnerConsent(coupleId, partnerUid) { partnerConsented ->
            if (partnerConsented) {
                viewModelScope.launch {
                    try {
                        repository.activateCouple(coupleId)
                    } catch (_: Exception) {
                        // Kalau gagal update status (misal kedua pihak nulis nyaris bersamaan),
                        // tetap dianggap selesai — status "active" bukan blocker fungsional di MVP ini.
                    }
                    _uiState.value = ConsentUiState.Done
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        listener?.remove()
    }
}

/** Dibutuhkan karena ConsentViewModel butuh parameter coupleId di constructor-nya. */
class ConsentViewModelFactory(private val coupleId: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return ConsentViewModel(coupleId) as T
    }
}
