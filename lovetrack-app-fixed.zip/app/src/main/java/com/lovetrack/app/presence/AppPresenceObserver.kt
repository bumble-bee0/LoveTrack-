package com.lovetrack.app.presence

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Dipasang di ProcessLifecycleOwner (level aplikasi), BUKAN di Activity.
 * Bedanya: kalau dipasang di Activity, onStart/onStop bisa kepicu berkali-kali
 * cuma karena pindah-pindah layar di dalam app. Di sini, onStart cuma sekali
 * kepicu pas app pindah dari background ke foreground beneran, begitu juga onStop.
 */
class AppPresenceObserver(
    private val repository: PresenceRepository = PresenceRepository()
) : DefaultLifecycleObserver {

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onStart(owner: LifecycleOwner) {
        scope.launch {
            try {
                repository.setOnline()
            } catch (_: Exception) {
                // Presence bukan fitur kritis — kalau gagal (misal belum login,
                // atau lagi tidak ada koneksi), diamkan saja, jangan sampai crash.
            }
        }
    }

    override fun onStop(owner: LifecycleOwner) {
        scope.launch {
            try {
                repository.setOffline()
            } catch (_: Exception) {
            }
        }
    }
}
