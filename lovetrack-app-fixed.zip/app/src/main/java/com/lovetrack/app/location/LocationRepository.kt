package com.lovetrack.app.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.lovetrack.app.util.awaitResult

data class LocationData(
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val accuracy: Float = 0f,
    val updatedAt: Timestamp? = null
)

/**
 * MANUAL location — one-shot, dipicu tombol "Bagikan lokasi saya".
 * BUKAN background tracking. Tidak ada foreground service, tidak ada
 * update otomatis berkelanjutan. Sesuai keputusan yang sudah dikunci.
 */
class LocationRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {

    /** Pengecekan izin lokasi WAJIB dilakukan di UI/ViewModel sebelum memanggil ini. */
    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocationOneShot(context: Context): Location {
        val client = LocationServices.getFusedLocationProviderClient(context)
        val cancellationTokenSource = CancellationTokenSource()
        val location = client.getCurrentLocation(
            Priority.PRIORITY_BALANCED_POWER_ACCURACY,
            cancellationTokenSource.token
        ).awaitResult()
        return location ?: throw Exception("Lokasi tidak tersedia, coba lagi (pastikan GPS aktif)")
    }

    suspend fun shareMyLocation(lat: Double, lng: Double, accuracy: Float) {
        val uid = auth.currentUser?.uid ?: throw Exception("Belum login")
        db.collection("locations").document(uid)
            .set(
                mapOf(
                    "lat" to lat,
                    "lng" to lng,
                    "accuracy" to accuracy,
                    "updatedAt" to Timestamp.now()
                ),
                SetOptions.merge()
            )
            .awaitResult()
    }

    fun listenLocation(uid: String, onChange: (LocationData?) -> Unit): ListenerRegistration {
        return db.collection("locations").document(uid)
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null && snapshot.exists()) {
                    onChange(
                        LocationData(
                            lat = snapshot.getDouble("lat") ?: 0.0,
                            lng = snapshot.getDouble("lng") ?: 0.0,
                            accuracy = (snapshot.getDouble("accuracy") ?: 0.0).toFloat(),
                            updatedAt = snapshot.getTimestamp("updatedAt")
                        )
                    )
                } else {
                    onChange(null)
                }
            }
    }
}
