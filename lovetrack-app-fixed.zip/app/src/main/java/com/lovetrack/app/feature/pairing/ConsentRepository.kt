package com.lovetrack.app.feature.pairing

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.lovetrack.app.util.awaitResult

/**
 * Consent itu PER-USER, bukan satu persetujuan yang berlaku buat berdua.
 * Masing-masing pasangan pilih sendiri apa yang mau dibagikan.
 */
class ConsentRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun getPartnerUid(coupleId: String, myUid: String): String {
        val snapshot = db.collection("couples").document(coupleId).get().awaitResult()
        val user1 = snapshot.getString("user1")
        val user2 = snapshot.getString("user2")
        return if (user1 == myUid) (user2 ?: "") else (user1 ?: "")
    }

    suspend fun hasConsented(coupleId: String, uid: String): Boolean {
        val snapshot = db.collection("consent").document(coupleId)
            .collection("users").document(uid).get().awaitResult()
        return snapshot.exists()
    }

    suspend fun submitConsent(coupleId: String, uid: String, locationSharing: Boolean, statusSharing: Boolean) {
        db.collection("consent").document(coupleId)
            .collection("users").document(uid)
            .set(
                hashMapOf(
                    "location_sharing" to locationSharing,
                    "status_sharing" to statusSharing
                )
            ).awaitResult()
    }

    fun listenPartnerConsent(
        coupleId: String,
        partnerUid: String,
        onChange: (Boolean) -> Unit
    ): ListenerRegistration {
        return db.collection("consent").document(coupleId)
            .collection("users").document(partnerUid)
            .addSnapshotListener { snapshot, _ ->
                onChange(snapshot?.exists() == true)
            }
    }

    suspend fun activateCouple(coupleId: String) {
        db.collection("couples").document(coupleId)
            .update("status", "active").awaitResult()
    }
}
