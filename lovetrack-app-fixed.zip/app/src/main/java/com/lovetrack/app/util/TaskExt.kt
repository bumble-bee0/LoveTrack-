package com.lovetrack.app.util

import com.google.android.gms.tasks.Task
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Firebase (Auth, Firestore) mengembalikan hasil dalam bentuk Task, bukan suspend function.
 * Extension ini yang menjembatani, biar kode di Repository bisa ditulis lurus pakai
 * suspend/await tanpa harus nambah library kotlinx-coroutines-play-services.
 */
suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { result -> cont.resume(result) }
    addOnFailureListener { e -> cont.resumeWithException(e) }
}
