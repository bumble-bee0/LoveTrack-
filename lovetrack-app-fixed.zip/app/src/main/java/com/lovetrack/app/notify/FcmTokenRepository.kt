package com.lovetrack.app.notify

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import com.lovetrack.app.util.awaitResult

/**
 * Menyimpan FCM token milik device ini ke users/{uid}.fcmToken di Firestore,
 * supaya Cloudflare Worker tahu ke mana harus mengirim notifikasi "Thinking of You"
 * saat pasangan menekan tombolnya.
 *
 * Dipanggil dari dua tempat:
 * 1. HomePlaceholderScreen — saat app dibuka & sudah login (self-heal token terbaru)
 * 2. LoveTrackMessagingService.onNewToken — saat Firebase mengganti token di background
 */
class FcmTokenRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun registerTokenForUser(uid: String) {
        val token = FirebaseMessaging.getInstance().token.awaitResult()
        saveToken(uid, token)
    }

    suspend fun saveToken(uid: String, token: String) {
        firestore.collection("users").document(uid)
            .set(mapOf("fcmToken" to token), SetOptions.merge())
            .awaitResult()
    }
}
