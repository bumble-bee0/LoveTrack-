package com.lovetrack.app.feature.chat

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.lovetrack.app.util.awaitResult

data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val text: String = "",
    val createdAt: Timestamp? = null
)

/**
 * Timestamp pakai FieldValue.serverTimestamp() (waktu SERVER), bukan jam HP —
 * biar urutan chat tidak kacau kalau jam kedua HP beda.
 * Status kirim (sending/failed) sengaja TIDAK disimpan di Firestore, cukup di
 * memori UI saja — sesuai kesepakatan biar skema data tetap sederhana.
 */
class ChatRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun sendMessage(coupleId: String, senderId: String, text: String) {
        db.collection("chat").document(coupleId)
            .collection("messages")
            .add(
                mapOf(
                    "senderId" to senderId,
                    "text" to text,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            .awaitResult()
    }

    fun listenMessages(coupleId: String, onChange: (List<ChatMessage>) -> Unit): ListenerRegistration {
        return db.collection("chat").document(coupleId)
            .collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null) {
                    val messages = snapshot.documents.map { doc ->
                        ChatMessage(
                            id = doc.id,
                            senderId = doc.getString("senderId") ?: "",
                            text = doc.getString("text") ?: "",
                            createdAt = doc.getTimestamp("createdAt")
                        )
                    }
                    onChange(messages)
                }
            }
    }
}
