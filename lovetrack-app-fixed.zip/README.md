# LoveTrack

Aplikasi companion presence & connection untuk pasangan LDR (Long Distance Relationship).
Android native — Kotlin + Jetpack Compose.

## Status: Milestone 1 (in progress) — Auth + Pairing + Consent

Fitur yang sudah jalan:
- Login & Register (Firebase Auth, email+password)
- Pairing dua akun pakai kode unik (generate/join, expired 15 menit, approve eksplisit)
- Consent per-user (pilih sendiri apa yang dibagikan ke pasangan)

Belum ada: Home asli, Map, Chat, notifikasi. Semua masih placeholder sampai
fitur di atas benar-benar stabil dites di 2 HP.

## Cara build APK

APK di-build otomatis lewat GitHub Actions setiap kali ada push ke branch `main`.
Setelah workflow selesai (tab **Actions** di repo ini), APK bisa didownload di bagian
**Artifacts** pada hasil run tersebut.

## Roadmap (ringkas)

- [x] Milestone 0 — Project setup, build pipeline terbukti jalan
- [ ] Milestone 1 — Auth, Pairing, Consent (sedang diuji), lalu Presence,
      Manual Location, Map, Chat, FCM "Thinking of you"
- [ ] Fase 2 — Voice note, Special Dates notification, Pet/Virtual Companion, Widget

## Tech Stack

- Kotlin + Jetpack Compose + Navigation Compose
- Firebase Auth + Firestore (tanpa Realtime Database, tanpa Storage)
- MapLibre Native Android SDK + MapTiler
- Firebase Cloud Messaging + Cloudflare Workers (untuk trigger notifikasi aman)
- GitHub Actions (build APK otomatis)
